package br.com.projetopaciente.model;

public class Doenca {
    private Integer idDoenca;
    private String nomeDoenca;

    public Doenca() {
    }

    public Doenca(Integer idDoenca, String nomeDoenca) {
        this.idDoenca = idDoenca;
        this.nomeDoenca = nomeDoenca;
    }

    public Integer getIdDoenca() {
        return idDoenca;
    }

    public void setIdDoenca(Integer idDoenca) {
        this.idDoenca = idDoenca;
    }

    public String getNomeDoenca() {
        return nomeDoenca;
    }

    public void setNomeDoenca(String nomeDoenca) {
        this.nomeDoenca = nomeDoenca;
    }

    
}
