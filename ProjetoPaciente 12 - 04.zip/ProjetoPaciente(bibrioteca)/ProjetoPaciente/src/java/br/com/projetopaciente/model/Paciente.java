package br.com.projetopaciente.model;

public class Paciente extends Pessoa{
    
    private Integer idPaciente;
    private String pesoPaciente;
    private TipoSanguineo idTipoSanguineo;

    public Paciente() {
    }

    public Paciente(Integer idPaciente, String pesoPaciente, TipoSanguineo idTipoSanguineo) {
        this.idPaciente = idPaciente;
        this.pesoPaciente = pesoPaciente;
        this.idTipoSanguineo = idTipoSanguineo;
    }
    

    public Integer getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(Integer idPaciente) {
        this.idPaciente = idPaciente;
    }

    public String getPesoPaciente() {
        return pesoPaciente;
    }

    public void setPesoPaciente(String pesoPaciente) {
        this.pesoPaciente = pesoPaciente;
    }

    public TipoSanguineo getIdTipoSanguineo() {
        return idTipoSanguineo;
    }

    public void setIdTipoSanguineo(TipoSanguineo idTipoSanguineo) {
        this.idTipoSanguineo = idTipoSanguineo;
    }

    

}
