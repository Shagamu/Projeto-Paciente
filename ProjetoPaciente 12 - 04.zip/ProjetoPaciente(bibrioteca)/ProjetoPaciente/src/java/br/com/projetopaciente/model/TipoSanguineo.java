package br.com.projetopaciente.model;

public class TipoSanguineo {
    private Integer idTipoSanguineo;
    private String nomeTipoSanguineo;

    public TipoSanguineo() {
    }

    public Integer getIdTipoSanguineo() {
        return idTipoSanguineo;
    }

    public void setIdTipoSanguineo(Integer idTipoSanguineo) {
        this.idTipoSanguineo = idTipoSanguineo;
    }

    public String getNomeTipoSanguineo() {
        return nomeTipoSanguineo;
    }

    public void setNomeTipoSanguineo(String nomeTipoSanguineo) {
        this.nomeTipoSanguineo = nomeTipoSanguineo;
    }

    
    
    
}
