package br.com.projetopaciente.controller;

import br.com.projetopaciente.dao.DoencaPacienteDAOImpl;
import br.com.projetopaciente.dao.PacienteDAOImpl;
import br.com.projetopaciente.dao.GenericDAO;
import br.com.projetopaciente.model.Doenca;
import br.com.projetopaciente.model.DoencaPaciente;
import br.com.projetopaciente.model.Paciente;
import br.com.projetopaciente.model.TipoSanguineo;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "CadastrarPaciente", urlPatterns = {"/CadastrarPaciente"})
public class CadastrarPaciente extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            HttpServletRequest httpServletRequest = (HttpServletRequest) request;
    
            HttpSession sessao = httpServletRequest.getSession();
    
            if (sessao.getAttribute("usuario") != null) {

            String nomePaciente = request.getParameter("nomePaciente");
            String enderecoPaciente = request.getParameter("enderecoPaciente");
            String pesoPaciente = request.getParameter("pesoPaciente");
            Integer idTipoSanguineo = Integer.parseInt(request.getParameter("idTipoSanguineo"));
            String[] idDoenca = request.getParameterValues("idDoenca");
            Integer quantidadeDoencas = idDoenca.length;
            
            String mensagem = null;

            Paciente paciente = new Paciente();
            
            paciente.setNomePessoa(nomePaciente);
            paciente.setEnderecoPessoa(enderecoPaciente);
            paciente.setPesoPaciente(pesoPaciente);
            paciente.setIdTipoSanguineo(new TipoSanguineo(idTipoSanguineo));
            Integer idPaciente = null;
            try {
                PacienteDAOImpl dao = new PacienteDAOImpl();
                idPaciente = dao.cadastrarPaciente(paciente);
                if (idPaciente > 0) {
                    paciente.setIdPaciente(idPaciente);
                    for (int i = 0; i < quantidadeDoencas; i++) {
                        DoencaPaciente doencapaciente = new DoencaPaciente();
                        doencapaciente.setIdDoenca(new Doenca(Integer.parseInt(idDoenca[i])));
                        doencapaciente.setIdPaciente(paciente);
                        
                        GenericDAO daoDoenca = new DoencaPacienteDAOImpl();
                        if (daoDoenca.cadastrar(doencapaciente)) {
                            mensagem = "Paciente cadastrado com sucesso!";
                        } else {
                            mensagem = "Problemas ao cadastrar Paciente. Verifique e tente novamente";
                                    
                        }
                    }
                } else {
                    mensagem = "Problemas ao cadastrar Paciente. "
                            + "Verifique os dados informados e tente novamente!";
                }
                request.setAttribute("mensagem", mensagem);
                request.getRequestDispatcher("CarregarTipoSanguineo").forward(request, response);
            } catch (Exception ex) {
                System.out.println("Problemas no Servlet ao cadastrar Paciente! Erro: " + ex.getMessage());
                ex.printStackTrace();
            }
            
            } else {
        ((HttpServletResponse) response). sendRedirect("index.jsp");
    }
        }
    }


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
