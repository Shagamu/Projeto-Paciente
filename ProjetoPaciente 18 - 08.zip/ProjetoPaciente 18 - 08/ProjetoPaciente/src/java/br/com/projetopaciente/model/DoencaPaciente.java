package br.com.projetopaciente.model;

public class DoencaPaciente {
    
    private Paciente idPaciente;
    private Doenca idDoenca;

    public DoencaPaciente() {
    }

    public DoencaPaciente(Paciente idPaciente, Doenca idDoenca) {
        this.idPaciente = idPaciente;
        this.idDoenca = idDoenca;
    }

    public DoencaPaciente(Paciente idPaciente) {
        this.idPaciente = idPaciente;
    }

    public DoencaPaciente(Doenca idDoenca) {
        this.idDoenca = idDoenca;
    }

    public Paciente getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(Paciente idPaciente) {
        this.idPaciente = idPaciente;
    }

    public Doenca getIdDoenca() {
        return idDoenca;
    }

    public void setIdDoenca(Doenca idDoenca) {
        this.idDoenca = idDoenca;
    }

   
    
}
