package br.com.projetopaciente.dao;

import br.com.projetopaciente.model.Paciente;
import br.com.projetopaciente.model.Pessoa;
import br.com.projetopaciente.model.TipoSanguineo;
import br.com.projetopaciente.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAOImpl implements GenericDAO {

    private Connection conn;

    public PacienteDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.getConnection();
            System.out.println("Conectado com sucesso!");
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Boolean cadastrar(Object object) {

        Paciente paciente = (Paciente) object;
        PreparedStatement stmt = null;

        String sql = "Insert into paciente(pesopaciente, idtiposanguineo, idpessoa) "
                + "values (?, ?, ?);";
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, paciente.getPesoPaciente());
            stmt.setInt(2, paciente.getIdTipoSanguineo().getIdTipoSanguineo());
            stmt.setInt(3, new PessoaDAOImpl().cadastrar(paciente));
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao cadastrar usuário! Erro: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<Object> listar() {
        List<Object> pacientes = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select pa.*, pe.*, ts.* from paciente pa, pessoa pe, tiposanguineo"
                + " ts where pe.idpessoa = pa.idpessoa and pa.idtiposanguineo = ts.idtiposanguineo;";

        try {
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Paciente paciente = new Paciente();
                paciente.setIdPaciente(rs.getInt("idpaciente"));
                paciente.setNomePessoa(rs.getString("nomepessoa"));
                paciente.setEnderecoPessoa(rs.getString("enderecopessoa"));
                paciente.setPesoPaciente(rs.getString("pesopaciente"));
                paciente.setIdPessoa(rs.getInt("idpessoa"));
                paciente.setIdTipoSanguineo(new TipoSanguineo(rs.getInt("idtiposanguineo")));
                paciente.setIdTipoSanguineo(new TipoSanguineo(rs.getString("nometiposanguineo")));
                pacientes.add(paciente);
            }
        } catch (SQLException ex) {
            System.out.println("Problemas ao listar pacientes! Erro:" + ex.getMessage());
            ex.printStackTrace();

        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro" + e.getMessage());
                e.printStackTrace();
            }
        }
        return pacientes;
    }

    @Override
    public Boolean excluir(int idOject) {
        PreparedStatement stmt = null;
        
        String sql = "delete from paciente where idpessoa = ?;"
                    +"commit;"
                    +"delete from pessoa where idpessoa = ?";
        
        try{
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idOject);
            stmt.setInt(2, idOject);
            stmt.executeUpdate();
            return true;
        }catch (Exception ex){
             System.out.println("Problemas ao listar os pacientes! Erro:" + ex.getMessage());
             ex.printStackTrace();
             return false;
        }finally{
            try{
                ConnectionFactory.closeConnection(conn, stmt);
            }catch (Exception e){
              System.out.println("Problemas ao finalizar conexão! Erro:" + e.getMessage());
              e.printStackTrace();
            }
        }
    }

    @Override
    public Object carregar(int idObject) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Paciente paciente = null;
        String sql = "select pa.*, pe.* from paciente pa, pessoa pe where pe.idpessoa = pa.idpessoa and pe.idpessoa = ?;";
        try {
            stmt = conn.prepareStatement (sql);
            stmt.setInt(1, idObject);
            rs = stmt.executeQuery();

            while (rs.next()) {
                paciente = new Paciente();
                paciente.setIdPaciente(rs.getInt("idpaciente"));
                paciente.setNomePessoa(rs.getString("nomepessoa"));
                paciente.setEnderecoPessoa(rs.getString("enderecopessoa"));
                paciente.setPesoPaciente(rs.getString("pesopaciente"));
                paciente.setIdPessoa(rs.getInt("idpessoa"));
                paciente.setIdTipoSanguineo(new TipoSanguineo(rs.getInt("idtiposanguineo")));
                paciente.setIdTipoSanguineo(new TipoSanguineo(rs.getString("nometiposanguineo")));
            }
        } catch (SQLException ex) {
            System.out.println("Problemas ao carregar pacientes! Erro:" + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro" + e.getMessage());
                e.printStackTrace();
            }
        }
        return paciente;
    }

@Override
    public Boolean alterar(Object object) {
        Paciente paciente = (Paciente) object;
        PreparedStatement stmt = null;
        String sql = "update paciente set pesopaciente = ?, idtiposanguineo = ? where idpessoa = ?;";
        try {
            stmt = conn.prepareStatement (sql);
            stmt.setString(1, paciente.getPesoPaciente());
            stmt.setInt(2, paciente.getIdPessoa());
            stmt.setInt(3, paciente.getIdTipoSanguineo().getIdTipoSanguineo());
            if (new PessoaDAOImpl().alterar(paciente)) {
                stmt.executeUpdate();
            return true;
            } else {
                  return false;
            }
        } catch (Exception ex) {
            System.out.println("Problemas ao alterar paciente! Erro: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
    }
    
}
