package br.com.projetopaciente.model;

public class TipoSanguineo {
    private Integer idTipoSanguineo;
    private String nomeTipoSanguineo;

    public TipoSanguineo() {
    }

    public TipoSanguineo(Integer idTipoSanguineo, String nomeTipoSanguineo) {
        this.idTipoSanguineo = idTipoSanguineo;
        this.nomeTipoSanguineo = nomeTipoSanguineo;
    }

    public TipoSanguineo(Integer idTipoSanguineo) {
        this.idTipoSanguineo = idTipoSanguineo;
    }

    public TipoSanguineo(String nomeTipoSanguineo) {
        this.nomeTipoSanguineo = nomeTipoSanguineo;
    }
    

    public Integer getIdTipoSanguineo() {
        return idTipoSanguineo;
    }

    public void setIdTipoSanguineo(Integer idTipoSanguineo) {
        this.idTipoSanguineo = idTipoSanguineo;
    }

    public String getNomeTipoSanguineo() {
        return nomeTipoSanguineo;
    }

    public void setNomeTipoSanguineo(String nomeTipoSanguineo) {
        this.nomeTipoSanguineo = nomeTipoSanguineo;
    }

    
}
