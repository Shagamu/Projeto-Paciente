package br.com.projetopaciente.model;

public class DoencaPaciente {
    
    private Integer idPaciente;
    private Integer idDoenca;

    public DoencaPaciente() {
    }

    public DoencaPaciente(Integer idPaciente, Integer idDoenca) {
        this.idPaciente = idPaciente;
        this.idDoenca = idDoenca;
    }

    public Integer getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(Integer idPaciente) {
        this.idPaciente = idPaciente;
    }

    public Integer getIdDoenca() {
        return idDoenca;
    }

    public void setIdDoenca(Integer idDoenca) {
        this.idDoenca = idDoenca;
    }
    
    
}
