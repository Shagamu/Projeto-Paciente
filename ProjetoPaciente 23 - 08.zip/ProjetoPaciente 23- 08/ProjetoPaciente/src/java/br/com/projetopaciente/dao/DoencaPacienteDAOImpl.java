package br.com.projetopaciente.dao;

import br.com.projetopaciente.model.Doenca;
import br.com.projetopaciente.model.DoencaPaciente;
import br.com.projetopaciente.model.TipoSanguineo;
import br.com.projetopaciente.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class DoencaPacienteDAOImpl implements GenericDAO{
    
    private Connection conn;

    public DoencaPacienteDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.getConnection();
            System.out.println("Conectado com sucesso!");
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }
    
    @Override
    public Boolean cadastrar(Object object) {

        DoencaPaciente doencapaciente = (DoencaPaciente) object;
        PreparedStatement stmt = null;

        String sql = "Insert into doencapaciente(iddoenca, idpaciente)"
                + "values (?, ?);";
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, doencapaciente.getIdDoenca().getIdDoenca());
            stmt.setInt(2, doencapaciente.getIdPaciente().getIdPaciente());
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao cadastrar paciente! Erro: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
    }
    @Override
    public List<Object> listar() {
        List<Object> doencas = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select * from doencas;";

        try {
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Doenca doenca = new Doenca();
                doenca.setIdDoenca(rs.getInt("iddoenca"));
                doenca.setNomeDoenca(rs.getString("nomedoenca"));
                doencas.add(doenca);
            }
        } catch (SQLException ex) {
            System.out.println("Problemas ao listar pacientes! Erro:" + ex.getMessage());
            ex.printStackTrace();

        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro" + e.getMessage());
                e.printStackTrace();
            }
        }
        return doencas;
    }



@Override
public Boolean excluir(int idOject) {
throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
}



@Override
public Object carregar(int idObject) {
throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
}



@Override
public Boolean alterar(Object object) {
throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
}

}




